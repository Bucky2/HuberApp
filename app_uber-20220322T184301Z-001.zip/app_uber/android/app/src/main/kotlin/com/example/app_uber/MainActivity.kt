package com.example.app_uber

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
