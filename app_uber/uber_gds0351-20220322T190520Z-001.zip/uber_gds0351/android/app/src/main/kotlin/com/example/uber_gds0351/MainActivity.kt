package com.example.uber_gds0351

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
